#include <stdlib.h>
#include <stdio.h>
#include "extmem.h"

#define POOLSIZE 10
#define RSIZE 16
#define SSIZE 32
#define BUFSIZE 7
struct twoTuple {
  int first;
  int second;
};

struct tuplePtr{
  int page_id;
  int tuple_id;
};

// 全局變量
struct twoTuple R_index[2];
struct twoTuple S_index[4];
Buffer buf_[POOLSIZE];
Buffer *b;

// 輔助函數聲明
int readBlockTupleFirst(unsigned char *blk, int i);
int readBlockTupleSecond(unsigned char *blk, int i);
int readBlockNextAddress(unsigned char *blk);
void init_buf();
void end_buf();
struct twoTuple innerSortPool();
void innerSortBuffer(Buffer * buf_ptr);
void innerSortPage(unsigned char * blk);
void swapPage(int x, int y, unsigned char *blk);
void printBuffer(Buffer *buf);
void readAndPrintPageFromDisk(int page_id);

struct twoTuple getPtr(struct tuplePtr current_tuple);
struct tuplePtr nextPtr(struct tuplePtr current_ptr);
void writeFourTuple(struct twoTuple R_tuple, struct twoTuple S_tuple, int END_OF_INPUT);
void writeTwoTuple(struct twoTuple tuple, int END_OF_INPUT);
int compareTwoTuple (struct twoTuple t1, struct twoTuple t2);

// 主要函數聲明
void linearSelect(int target, int start_id, int end_id);
void twoPassMultiwayMergeSort();
void indexSelect(int tartget1, int target2);
void joinAlgorithm();
void intersection();
void unionOperation();

void unionOperation(){
  // 356-371 404-435

  struct tuplePtr R_tuple_ptr = {356, 0};
  struct tuplePtr R_tuple_ptr_back = {356, 0};
  struct tuplePtr S_tuple_ptr = {404, 0};

  struct twoTuple R_value = getPtr(R_tuple_ptr);
  struct twoTuple S_value = getPtr(S_tuple_ptr);
  struct twoTuple S_value_back = S_value;

  int state = 0;

  while (1) {
    if (R_value.first == 1000 && S_value.first == 1000) {
      break;
    }
    
    switch(state) {
    case 0:
      if (compareTwoTuple(R_value, S_value) == 0) {
	writeTwoTuple(R_value, 0);
	R_tuple_ptr = nextPtr(R_tuple_ptr);
	R_value = getPtr(R_tuple_ptr);
      } else if (compareTwoTuple(R_value, S_value) == 1) {
	writeTwoTuple(S_value, 0);
	S_tuple_ptr = nextPtr(S_tuple_ptr);
	S_value = getPtr(S_tuple_ptr);
      } else {
	state = 1;
	R_tuple_ptr_back = R_tuple_ptr;
      }
      break;

    case 1:
      if (R_value.first == S_value.first && R_value.second == S_value.second) {
	printf("find one\n");

	writeTwoTuple(R_value, 0);

	R_tuple_ptr = nextPtr(R_tuple_ptr);
	R_value = getPtr(R_tuple_ptr);
      } else {
	S_value_back = S_value;

	S_tuple_ptr = nextPtr(S_tuple_ptr);
	S_value = getPtr(S_tuple_ptr);
	state = 2;
      }
      break;

    case 2:
      if (S_value.first == S_value_back.first) {
	R_tuple_ptr = R_tuple_ptr_back;
	state = 1;
      } else {
	state = 0;
      }
      break;
    }
  }

  writeTwoTuple(R_value, 1);
}

void intersection(){
  // 356-371 404-435
  struct tuplePtr R_tuple_ptr = {356, 0};
  struct tuplePtr R_tuple_ptr_back = {356, 0};
  struct tuplePtr S_tuple_ptr = {404, 0};

  struct twoTuple R_value = getPtr(R_tuple_ptr);
  struct twoTuple S_value = getPtr(S_tuple_ptr);
  struct twoTuple S_value_back = S_value;

  int state = 0;

  while (1) {
    if (R_value.first == 1000 && S_value.first == 1000) {
      break;
    }
    switch(state) {
    case 0:
      if (R_value.first < S_value.first) {
	R_tuple_ptr = nextPtr(R_tuple_ptr);
	R_value = getPtr(R_tuple_ptr);
      } else if (R_value.first > S_value.first) {
	S_tuple_ptr = nextPtr(S_tuple_ptr);
	S_value = getPtr(S_tuple_ptr);
      } else {
	state = 1;
	R_tuple_ptr_back = R_tuple_ptr;
      }
      break;

    case 1:
      // NOTE modified here
      if (R_value.first == S_value.first && R_value.second == S_value.second) {
	printf("intersection on R(%d, %d) S(%d, %d)\n",
	       R_value.first,
	       R_value.second,
	       S_value.first,
	       S_value.second);
	writeTwoTuple(R_value, 0);

	R_tuple_ptr = nextPtr(R_tuple_ptr);
	R_value = getPtr(R_tuple_ptr);
      } else {
	S_value_back = S_value;

	S_tuple_ptr = nextPtr(S_tuple_ptr);
	S_value = getPtr(S_tuple_ptr);
	state = 2;
      }
      break;

    case 2:
      if (S_value.first == S_value_back.first) {
	R_tuple_ptr = R_tuple_ptr_back;
	state = 1;
      } else {
	state = 0;
      }
      break;
    }
  }
  writeTwoTuple(R_value, 1);
}

void linearSelect(int target, int start_id, int end_id){
  init_buf();
  int buf_index = 0;
  unsigned char *blk;
  for (int i = start_id ; i <= end_id ; i++){
    if (buf_index == POOLSIZE) {
      init_buf();
      end_buf();
      buf_index = 0;
    }
    if (buf_[buf_index].numFreeBlk == 0) {
      buf_index = buf_index + 1;
      continue;
    }

    printf("read block %d\n", i);
    blk = readBlockFromDisk(i, &buf_[buf_index]);
    for (int k = 0 ; k < 7 ; k++) {
      int first = readBlockTupleFirst(blk,k);
      int second = readBlockTupleSecond(blk,k);
      if (first == target) {
	printf("find one ");
	printf("(%d, %d)\n",first, second);
      }
    }
  }
  end_buf();
}
void twoPassMultiwayMergeSort(){
  init_buf();
  int base = 0;

  // 將 R 分爲 兩組，每組 8 個 page
  // 將這 8 個 page 裝載的時候，考慮到 R 數量真的是太少了，
  // 我們在每一個 buf 裏面裝載 2 個 page，這樣能夠使用到
  // 4 個 buf 了。

  for (int i = 0 ; i < 4 ; i++) {
    for (int j = 0 ; j < 2 ; j++) {
      base++;
      readBlockFromDisk(base, buf_ + i);
    }
  }
  // 在這裏，innerSortPool 函數能夠將 buf 內的所有有效 tuple
  // 進行存儲，第一個 page 的 id 爲 340
  innerSortPool();
  end_buf();

  init_buf();
  // 接下來進行同樣的操作，也就是，裝載和 sort 的操作。
  // 在這裏，代碼基本不用變動，這是因爲 base 存儲着將要讀如的地址。
  
  for (int i = 0 ; i < 4 ; i++) {
    for (int j = 0 ; j < 2 ; j++) {
      base++;
      readBlockFromDisk(base, buf_ + i);
    }
  }
  innerSortPool();
  end_buf();

  // 從這裏開始便是 merge 的部分了
  printf("start merging\n");

  init_buf();
  // 這裏進行兩次裝填，一次裝填 8 個 page
  // 這 8 個 page 放在 4 個 buf 裏面。
  // again 這是因爲 R 實在是太少了。
  // 340 和 348 是兩個集合的起始地址
  int base_one = 340;
  int base_two = 348;
  for (int j = 0 ; j < 4 ; j++) {
    readBlockFromDisk(base_one + j, buf_ + j);
    readBlockFromDisk(base_two + j, buf_ + j);
  }
  base_one += 4;
  base_two += 4;
  // 在這裏寫入 index。index 是一個 twoTuple。
  // 存儲 page id 和值
  R_index[0] = innerSortPool();
  end_buf();

  // 從這裏開始便是 merging 的第二部分
  init_buf();
  for (int j = 0 ; j < 4 ; j++) {
    readBlockFromDisk(base_one + j, buf_ + j);
    readBlockFromDisk(base_two + j, buf_ + j);
  }
  R_index[1] = innerSortPool();
  end_buf();

  // 現在我們將要對 table S 進行 sort
  printf("next we are going to sort S\n");
  // 對於 S，其有 32 個 page，我們每次裝入 8 個 page
  // 還是類似的，這 8 個 page 裝入 4 個 buf，每個 buf 只有兩個 page

  base = 17;
  // 這個循環是說，這裏有四個 index block，於是說在這個循環內。
  // 在這裏，innerSortPool 會將結果寫入到 372 到 403 page
  // 372-379 380-387 388-395 396-403
  for (int i = 0 ; i < 4 ; i++) {
    init_buf();
    for (int j = 0 ; j < 4 ; j++) {
      for (int k = 0 ; k < 2 ; k++) {
	readBlockFromDisk(base++, buf_ + j);
      }
    }
    innerSortPool();
    end_buf();
  }
  // 從這裏開始進行 merging
  base_one = 372;
  base_two = 380;
  int base_three = 388;
  int base_four  = 396;
  printf("starting merging for table S\n");
  // 對於接下來的 merging，其將會從 404 開始寫入 32 個 page
  // 也就是，從 404 到 435
  for (int i = 0 ; i < 4 ; i++) {
    init_buf();
    for (int j = 0 ; j < 2 ; j++) {
      readBlockFromDisk(base_one++, buf_ + 0);
      readBlockFromDisk(base_two++, buf_ + 1);
      readBlockFromDisk(base_three++, buf_ + 3);
      readBlockFromDisk(base_four++, buf_ + 4);
    }
    // 我們會進行 index 的賦值。
    S_index[i] = innerSortPool();
    end_buf();
  }
}

void indexSelect(int target1, int target2) {
  // 根據 R index 來進行選取。
  int n = 0;
  if (R_index[1].second > target1) {
    printf("choose index block 0\n");
  } else {
    n = 1;
    printf("choose index block 1\n");
  }
  // 如果說剛好等於的話，需要查找兩個 index，這是因爲這個值
  // 可能橫跨了兩個 index block
  linearSelect(target1, R_index[n].first, R_index[n].first + 8);

  // 接下來對 S index 進行選取。
  // S index 總共有 4 個。使用一個 while 語句來進行選取

  int i = 0;
  while (S_index[i].second < target2)
    i++;
  if (i == 0) {
    printf("no index block available\n");
    return ;
  } else {
    i--;
    printf("choose index block %d\n", i);
  }

  linearSelect(target2, S_index[i].first, S_index[i].first + 8);
}

struct twoTuple getPtr(struct tuplePtr current_tuple) {

  // 在這裏，我們只使用 buf 的 2 個 page，這是因爲數據實在是太少了。
  // 每一個 page 能夠裝 7 個 tuple
  static Buffer buf;
  static int table[2] = {-1};
  static int flag = 0;
  static int free_frame = 0;
  static unsigned char * blk;
  if (flag == 0) {
    flag = 1;
    initBuffer(520, 64, &buf);
    // the next three line is actually useless
    blk = getNewBlockInBuffer(&buf);
    blk = getNewBlockInBuffer(&buf);
    blk = blk - 65;
  }

  // this one is used to stop the join
  if (current_tuple.page_id == 372 || current_tuple.page_id == 436) {
    struct twoTuple foo = {1000, 1000};
    return foo;
  }
  
  // use a simple statement to find
  // the table entry for the current page
  // if not find, then the entry remains -1
  int entry = -1;
  for (int i = 0 ; i < 2 ; i++) {
    if (table[i] == current_tuple.page_id) {
      entry = i;
    }
  }

  // page fault
  if (entry == -1) {
    // this actually achieve a simple FIFO replacement strategy
    // printf("page fault in helper function\n");
    entry = free_frame;
    freeBlockInBuffer(blk + 65 * free_frame, &buf);
    printf("reading block %d\n", current_tuple.page_id);
    readBlockFromDisk(current_tuple.page_id, &buf);
    table[free_frame] = current_tuple.page_id;

    free_frame = (free_frame + 1) % 2;
  }

  struct twoTuple foo = {
    readBlockTupleFirst(blk + entry * 65, current_tuple.tuple_id),
    readBlockTupleSecond(blk + entry * 65, current_tuple.tuple_id)
  };
  return foo;
}

struct tuplePtr nextPtr(struct tuplePtr current_ptr) {

  struct tuplePtr foo;
  foo.page_id = current_ptr.page_id;
  if (current_ptr.tuple_id == 7) {
    foo.tuple_id = 0;
    foo.page_id += 1;
  } else {
    foo.tuple_id = current_ptr.tuple_id + 1;
  }
  return foo;
}

void joinAlgorithm(){
  // join action can be described with an automaton

  // 356 371 404 435
  struct tuplePtr R_tuple_ptr = {356, 0};
  struct tuplePtr R_tuple_ptr_back = {356, 0};
  struct tuplePtr S_tuple_ptr = {404, 0};

  struct twoTuple R_value = getPtr(R_tuple_ptr);
  struct twoTuple S_value = getPtr(S_tuple_ptr);
  struct twoTuple S_value_back = S_value;

  int state = 0;

  while (1) {
    // when the ptr both reach the end, return
    if (R_value.first == 1000 && S_value.first == 1000) {
      break;
    }
    switch(state) {
    case 0:
      if (R_value.first < S_value.first) {
	R_tuple_ptr = nextPtr(R_tuple_ptr);
	R_value = getPtr(R_tuple_ptr);
      } else if (R_value.first > S_value.first) {
	S_tuple_ptr = nextPtr(S_tuple_ptr);
	S_value = getPtr(S_tuple_ptr);
      } else {
	state = 1;
	R_tuple_ptr_back = R_tuple_ptr;
      }
      break;

    case 1:
      if (R_value.first == S_value.first) {
	printf("join once on R(%d, %d) S(%d, %d)\n",
	       R_value.first,
	       R_value.second,
	       S_value.first,
	       S_value.second);
	writeFourTuple(R_value, S_value, 0);

	R_tuple_ptr = nextPtr(R_tuple_ptr);
	R_value = getPtr(R_tuple_ptr);
      } else {
	S_value_back = S_value;

	S_tuple_ptr = nextPtr(S_tuple_ptr);
	S_value = getPtr(S_tuple_ptr);
	state = 2;
      }
      break;

    case 2:
      if (S_value.first == S_value_back.first) {
	R_tuple_ptr = R_tuple_ptr_back;
	state = 1;
      } else {
	state = 0;
      }
      break;
    }
  }
  writeFourTuple(R_value, S_value, 1);
}

void writeFourTuple (struct twoTuple R_tuple, struct twoTuple S_tuple, int END_OF_INPUT) {
  static Buffer buf;
  static int flag = 0;
  // there are 8 pages in one buffer
  static int page_ptr = 0;
  static int tuple_ptr = 0;
  static int page_id = 501;
  static unsigned char * blk;

  
  if (flag == 0) {
    flag = 1;
    initBuffer(520, 64, &buf);
    blk = getNewBlockInBuffer(&buf);
    for (int i = 1 ; i < 8 ; i++) {
      getNewBlockInBuffer(&buf);
    }
  }

  if (tuple_ptr == 6 || END_OF_INPUT) {
    tuple_ptr = 0;
    printf("write to block %d\n", page_id);
    writeBlockToDisk(blk + page_ptr * 65, page_id, &buf);
    page_id++;
    page_ptr = (page_ptr + 1) % 8;
  }

  if (END_OF_INPUT) {
    tuple_ptr = 0;
    page_ptr = 0;
    return;
  }

  sprintf(blk + page_ptr * 65 + tuple_ptr * 8 + 0, "%d", R_tuple.first);
  sprintf(blk + page_ptr * 65 + tuple_ptr * 8 + 4, "%d", R_tuple.second);
  sprintf(blk + page_ptr * 65 + tuple_ptr * 8 + 8, "%d", S_tuple.first);
  sprintf(blk + page_ptr * 65 + tuple_ptr * 8 + 12,"%d", S_tuple.second);
  tuple_ptr += 2;
}

struct twoTuple innerSortPool(){
  struct twoTuple ans;
  int flag = 0;
  // page_index tuple_index 是用來標誌某一個 buf 正要被掃描的 tuple 的位置。
  int page_index[POOLSIZE] = {0};
  int tuple_index[POOLSIZE] = {0};

  for (int i = 0 ; i < POOLSIZE ; i++) {
    innerSortBuffer(buf_ + i);
  }
  // printBuffer(buf_ + 0);

  // buf_done is for marking is a buf is done scanning
  int buf_done[POOLSIZE] = {0};
  // done is used to count the number of done buf
  int done = 0;
  // pool_index is to scan all over the pool
  int pool_index = 0;

  // initializing done array. because some buf could be empty
  for (int i = 0 ; i < POOLSIZE ; i++) {
    if (buf_[i].numFreeBlk == buf_[i].numAllBlk){
      buf_done[i] = 1;
      done++;
    }
  }

  // 我們設定一個 page，如果說這個 page 裏面放了 7 個 tuple，則進行寫入
  Buffer buf_out;
  initBuffer(520, 64, &buf_out);
  unsigned char * page_out = getNewBlockInBuffer(&buf_out);
  // page id 是寫入的 page 的 id。
  static int page_id_base = 340;
  int tuple_index_out = 0;

  while (done != POOLSIZE){
    int min = 1000;
    int min_buf_index = 0;
    int min_page_index = 0;
    int min_tuple_index = 0;
    // 我們使用一個 for loop 來找到所有 buf 之中最小的 tuple
    for (int i = 0 ; i < POOLSIZE ; i++) {
      // 如果說一個buf已經處理完了，那麼直接跳過。
      if (buf_done[i] == 1)
	continue;
      unsigned char * blk = buf_[i].data + 65 * page_index[i] + 1;
      if (readBlockTupleFirst(blk, tuple_index[i]) <= min) {
	min_buf_index = i;
	min_page_index = page_index[i];
	min_tuple_index = tuple_index[i];
	min = readBlockTupleFirst(blk, tuple_index[i]);
      }
    }
    // printf("%d\n", min);

    // 在找到了最小的 tuple 之後，寫入 page_out
    if (flag == 0) {
      flag = 1;
      ans.first = page_id_base;
      ans.second = min;
    }
    for (int k = 0 ; k < 8 ; k++) {
      // 在這裏你應該注意這個 + 1。因爲這是 page 前面的一個標誌 byte 導致的。
      *(page_out + tuple_index_out * 8 + k) =
	*(buf_[min_buf_index].data + 65 * min_page_index + min_tuple_index * 8 + k + 1);
      // printf("%c", *(page_out + tuple_index_out * 8 + k));
    }
    // printf("\n");
    tuple_index_out++;
    // 如果說 tuple index out 爲 7，則這個 page 已經滿了，則我們需要在最後 8 個
    // byte 裏面寫入下一個 page 的 page id。然後寫入磁盤
    if (tuple_index_out == 7) {
      // TODO
      // sprintf((char *)page_out + 55, "%d", page_id_base + 1);
      printf("write to disk, page id: %d\n", page_id_base);
      writeBlockToDisk(page_out, page_id_base, &buf_out);
      page_id_base++;
      tuple_index_out = 0;
    }

    // 在找到最小的tuple之後，進行更新。主要是對index進行更新。
    tuple_index[min_buf_index]++;
    if (tuple_index[min_buf_index] == 7) {
      tuple_index[min_buf_index] = 0;
      page_index[min_buf_index]++;
    }

    // 如果說當前的index已經到了最大了。則說明這個buf已經不需要再檢查了。
    // 因爲並不是所有的buf裏面都裝滿着page
    if (page_index[min_buf_index] == 8 - buf_[min_buf_index].numFreeBlk) {
      page_index[min_buf_index] = 0;
      buf_done[min_buf_index] = 1;
      done++;
    }
  }
  return ans;
}

void innerSortBuffer(Buffer * buf_ptr){
  // 這裏是一個基本的檢查。可以看出的是，若是本 buf 爲空
  // 則不應該獲取任何新的 page，這就是說。對於空 buf
  // 下面的 blk_out = getNewblockinbuffer 也會被執行
  // 那麼 buf_out 就會被人作爲有一個不空閒的 blk
  // if (buf_ptr->numFreeBlk == buf_ptr->numAllBlk)
  //  return ;

  // 爲什麼使用 b 呢？我也不記得了
  b = buf_ptr;

  // num 記錄的是 buf 內部有效的 page 數量
  // 其實可以直接使用 buf 的 field 來得出
  // 鑑於能動就行，就不敢改了。
  // num = b->numAllblk - b->numFreeblk;
  int num = 0;
  unsigned char * blk;

  // 對於 buf 內部的所有 page，都調用函數進行排序。
  // 於是在這個 loop 之後，所有 page 的有序的。
  for (int i = 0 ; i < BUFSIZE ; i++) {
    // 在這裏 blk 的取值需要注意 + 1 是幹什麼的
    blk = b->data + i*65;
    if (*blk == BLOCK_AVAILABLE)
      break;
    num++;
    innerSortPage(blk+1);
  }
  if (num == 0) {
    return ;
  }

  // blk 現在指向的是第一個 page
  blk = b->data + 1;
  Buffer buf_out;
  initBuffer(520, 64, &buf_out);
  int page_index_buf_out = 0;
  int tuple_index_buf_out =0;
  unsigned char * blk_out = getNewBlockInBuffer(&buf_out);

  int indexes[8] = {0};
  int count = 0;
  while (count != num) {
    int min = 1000;
    int index = 0;
    // find the lowest tuple
    for (int j = 0 ; j < num ; j++){
      if (indexes[j] == 7)
	continue;
      int temp = readBlockTupleFirst(blk + j * 65, indexes[j]);
      if (temp <= min) {
	min = temp;
	index = j;
      }
    }
    // find the smallest tuple. time to write it to the buf_out
    if (tuple_index_buf_out == 7){
      page_index_buf_out++;
      tuple_index_buf_out = 0;
      blk_out = getNewBlockInBuffer(&buf_out);
    }
    
    // here what we do is copy one tuple
    for (int k = 0 ; k < 8 ; k++){
      *(blk_out + tuple_index_buf_out * 8 + k) =
	*(blk + 65 * index + indexes[index] * 8 + k);
    }
    tuple_index_buf_out++;

    // int first = readBlockTupleFirst(blk + 65 * index, indexes[index]);
    // int second = readBlockTupleSecond(blk + 65 * index, indexes[index]);
    // printf("%d %d\n", first, second);
    // not relative to buf_out
    if (++indexes[index] == 7)
	count++;
  }
  // printBuffer(&buf_out);
  *buf_ptr = buf_out;
}

void innerSortPage(unsigned char *blk){
  for (int i = 0 ; i < 7 ; i++) {
    for (int j =  0 ; j < 7 - i - 1 ; j++){
      if (readBlockTupleFirst(blk, j) > readBlockTupleFirst(blk, j + 1)) {
	swapPage(j, j + 1, blk);
      }
      else if (readBlockTupleFirst(blk, j) == readBlockTupleFirst(blk, j + 1)) {
	if (readBlockTupleSecond(blk, j) > readBlockTupleSecond(blk, j + 1)) {
	  swapPage(j, j + 1, blk);
	}
      }
    }
  }
}

void swapPage(int x, int y, unsigned char *blk){
  if (x >= 7 || y >= 7) {
    return;
  }
  char temp;
  for (int k = 0 ; k < 8 ; k++) {
#define EXP(X) (blk + (X) * 8 + k)
    temp = *EXP(x);
    *EXP(x) = *EXP(y);
    *EXP(y) = temp;
#undef EXP
  }
}


void printBuffer(Buffer *buf){
  unsigned char * blk;
  for (int i = 0 ; i < 8 ; i++) {
    printf("\n");
    blk = buf->data + 65 * i;
    if (*blk == BLOCK_AVAILABLE)
      break;
    for (int j = 0 ; j < 7 ; j++) {
	int first = readBlockTupleFirst(blk + 1, j);
	printf("%d\n", first);
    }
  }
}


/**
 * @param: blk a pointer to block. i the index of the tuple.
 * note there are seven tuple in a block
 */
int readBlockTupleFirst(unsigned char *blk, int i){
  char str[4];
  for (int k = 0; k < 4; k++){
    str[k] = *(blk + i*8 + k);
  }
  return atoi(str);
}

/**
 * @param: blk a pointer to block. i the index of the tuple.
 * note there are seven tuple in a block
 * @return: it will the second element of the tuple
 */
int readBlockTupleSecond(unsigned char *blk, int i){
  char str[4];
  for (int k = 0; k < 4; k++){
    str[k] = *(blk + i*8 + 4 + k);
  }
  return atoi(str);
}

int readBlockNextAddress(unsigned char *blk){
  char str[5];
  for (int k = 0 ; k < 4 ; k++){
    str[k] = *(blk + 7 * 8 + k);
  }
  return atoi(str);
}

void init_buf(){
  for (int i = 0 ; i < POOLSIZE ; i++) {
    b = buf_ + i;
    if (!initBuffer(520, 64, b)){
        perror("Buffer Initialization Failed!\n");
        return ;
    }
  }
}

void end_buf(){
  for (int i = 0 ; i < POOLSIZE ; i++) {
    b = buf_ + i;
    // for (int k = 0 ; k < 8 ; k++) {
    //   *(b->data + k*9) = '\0';
    // }
    freeBuffer(b);
  }
}

void readAndPrintPageFromDisk(int page_id) {
  Buffer buf;
  initBuffer(520, 64, &buf);
  unsigned char * blk = readBlockFromDisk(page_id, &buf);

  // note here from 7 to 6
  for (int i = 0 ; i < 6 ; i++) {
    int first = readBlockTupleFirst(blk, i);
    int second = readBlockTupleSecond(blk, i);
    printf("%d %d\n", first, second);
  }
}

void readAndPrintPageFromDisk2(int page_id) {
  Buffer buf;
  initBuffer(520, 64, &buf);
  unsigned char * blk = readBlockFromDisk(page_id, &buf);

  // note here from 7 to 6
  for (int i = 0 ; i < 7 ; i++) {
    int first = readBlockTupleFirst(blk, i);
    int second = readBlockTupleSecond(blk, i);
    printf("%d %d\n", first, second);
  }
}

int compareTwoTuple (struct twoTuple t1, struct twoTuple t2) {
  if (t1.first < t2.first) {
    return 0;
  } else if (t1.first > t2.first) {
    return 1;
  } else {
    if (t1.second < t2.second) {
      return 0;
    } else if (t1.second > t2.second) {
      return 1;
    } else {
      return 2;
    }
  }
}

void writeTwoTuple (struct twoTuple tuple, int END_OF_INPUT) {
  static Buffer buf;
  static int flag = 0;
  // there are 8 pages in one buffer
  static int page_ptr = 0;
  static int tuple_ptr = 0;
  static int page_id = 601;
  static unsigned char * blk;

  
  if (flag == 0) {
    flag = 1;
    initBuffer(520, 64, &buf);
    blk = getNewBlockInBuffer(&buf);
    for (int i = 1 ; i < 8 ; i++) {
      getNewBlockInBuffer(&buf);
    }
  }

  if (tuple_ptr == 7 || END_OF_INPUT) {
    tuple_ptr = 0;

    printf("write to block %d\n", page_id);
    writeBlockToDisk(blk + page_ptr * 65, page_id, &buf);
    page_id++;
    page_ptr = (page_ptr + 1) % 8;
  }

  if (END_OF_INPUT) {
    tuple_ptr = 0;
    page_ptr = 0;
    return;
  }

  /* for (int i = 0 ; i < 16 ; i++) { */
  /*   *(blk + page_ptr * 65 + tuple_ptr * 8 + i) = '\0'; */
  /* } */
  sprintf(blk + page_ptr * 65 + tuple_ptr * 8 + 0, "%d", tuple.first);
  sprintf(blk + page_ptr * 65 + tuple_ptr * 8 + 4, "%d", tuple.second);
  tuple_ptr += 1;
}

int main(int argc, char **argv) {
  printf("\n========== start linear select\n\n");
  linearSelect(95, 1, 16);
  printf("\nlinear select table S\n");
  linearSelect(107, 17, 48);
  printf("\n========== start TPMMS\n\n");
  twoPassMultiwayMergeSort();
  /* for (int i = 356 ; i <= 371 ; i++) { */
  /*   printf("this is one page %d\n", i); */
  /*   readAndPrintPageFromDisk(i); */
  /* } */
  /* for (int i = 404 ; i <= 435 ; i++) { */
  /*   printf("this is one page %d\n", i); */
  /*   readAndPrintPageFromDisk(i); */
  /* } */

  printf("\n========== start index select\n\n");
  indexSelect(95, 107);

  printf("\n========== start join\n\n");
  joinAlgorithm();

  /* for (int i = 501 ; i <= 523 ; i++) { */
  /*   printf("this is page %d\n", i); */
  /*   readAndPrintPageFromDisk(i); */
  /* } */

  printf("\n========== start intersection\n\n");
  intersection();
  /* for (int i = 524 ; i <= 525 ; i++) { */
  /*   printf("this is page %d\n", i); */
  /*   readAndPrintPageFromDisk(i); */
  /* } */


  printf("\n========== start union\n\n");
  unionOperation();
  /* for (int i = 601 ; i <= 655 ; i++) { */
  /*   printf("this is page %d\n", i); */
  /*   readAndPrintPageFromDisk2(i); */
  /* } */

  printf("\n========== summary\n\n");
  printf("the resulf of merge is stored in page 356 to 371 for R\n"
	 "page 404 to 435 for S\n");
  printf("the result of join is in page 501 to 523\n");
  printf("the result of intersection is in page 601\n");
  printf("the result of union is in page 602 to 656\n");
}
