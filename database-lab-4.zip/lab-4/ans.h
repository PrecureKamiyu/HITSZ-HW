#include<stdio.h>
#include "extmem.h"
#include <stdlib.h>
void readAndPrintPageFromDisk2(int page_id);
void readAndPrintPageFromDisk(int page_id);
int readBlockTupleFirst(unsigned char *blk, int i);
int readBlockTupleSecond(unsigned char *blk, int i);


void readAndPrintPageFromDisk2(int page_id) {
  Buffer buf;
  initBuffer(520, 64, &buf);
  unsigned char * blk = readBlockFromDisk(page_id, &buf);

  // note here from 7 to 6
  for (int i = 0 ; i < 7 ; i++) {
    int first = readBlockTupleFirst(blk, i);
    int second = readBlockTupleSecond(blk, i);
    printf("%d %d\n", first, second);
  }
}

void readAndPrintPageFromDisk(int page_id) {
  Buffer buf;
  initBuffer(520, 64, &buf);
  unsigned char * blk = readBlockFromDisk(page_id, &buf);

  // note here from 7 to 6
  for (int i = 0 ; i < 6 ; i++) {
    int first = readBlockTupleFirst(blk, i);
    int second = readBlockTupleSecond(blk, i);
    printf("%d %d\n", first, second);
  }
}

int readBlockTupleFirst(unsigned char *blk, int i){
  char str[4];
  for (int k = 0; k < 4; k++){
    str[k] = *(blk + i*8 + k);
  }
  return atoi(str);
}

int readBlockTupleSecond(unsigned char *blk, int i){
  char str[4];
  for (int k = 0; k < 4; k++){
    str[k] = *(blk + i*8 + 4 + k);
  }
  return atoi(str);
}
