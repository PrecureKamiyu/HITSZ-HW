#include <stdio.h>
#include "ans.h"
#include "extmem.h"
void readAndPrintPageFromDisk2(int page_id);

int main () {
  printf("============== sort\n");
  printf("\nnext is for R\n");
  for (int i = 356 ; i <= 371 ; i++) {
    printf("page %d\n", i);
    readAndPrintPageFromDisk(i);
  }

  printf("\nnext is for S\n");
  for (int i = 404 ; i <= 435 ; i++) {
    printf("page %d\n", i);
    readAndPrintPageFromDisk(i);
  }
}
