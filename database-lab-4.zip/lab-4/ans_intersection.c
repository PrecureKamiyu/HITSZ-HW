#include<stdio.h>
#include "ans.h"

void readAndPrintPageFromDisk(int page_id);

int main () {
  printf("\n========== result intersection\n\n");
  for (int i = 601 ; i <= 601 ; i++) {
    printf("page %d\n", i);
    readAndPrintPageFromDisk(i);
  }
}
