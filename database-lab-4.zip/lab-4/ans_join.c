#include<stdio.h>
#include"ans.h"

void readAndPrintPageFromDisk(int page_id);

int main () {
  printf("=========== result of join\n");
  printf("note that the four-tuple is stored\nand every page has three four-tuple");
  for (int i = 501 ; i <= 523 ; i++) {
    printf("page %d\n", i);
    readAndPrintPageFromDisk(i);
  }
}
