#include<stdio.h>
#include "ans.h"

void readAndPrintPageFromDisk2(int page_id);

int main () {
  printf("=========== result for union\n");
  for (int i = 602 ; i <= 656 ; i++) {
    printf("this is page %d\n", i);
    readAndPrintPageFromDisk2(i);
  }
}
