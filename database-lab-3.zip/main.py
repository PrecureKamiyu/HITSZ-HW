import typing
from PyQt5 import QtGui
from PyQt5.QtWidgets import QApplication,QWidget,QVBoxLayout,QTreeWidget,QTreeWidgetItem,QHBoxLayout,QStackedLayout
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QPushButton, 
    QFormLayout, QLineEdit, QTextEdit, QSpinBox, QComboBox, QHBoxLayout,
    QMessageBox, QTableWidget, QTableWidgetItem, QPlainTextEdit, QTextBrowser, QStackedWidget, QMainWindow)

from PyQt5.QtGui import QFont, QPixmap, QIcon
from PyQt5.QtCore import Qt, pyqtSlot
import sys
import mysql.connector

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.db = Database('localhost', 'root', 'zhrmghgws1', 'yum')
        self.hello = 1
        self.getUser()
        self.initializeUI()

    def getUser(self):
        self.users = self.db.execute_query('select user_name, user_pwd from users;')
        print(self.users)
        foo = self.db.execute_query('select user from mysql.user;')
        for name in foo:
            print(name[0])

    def initializeUI(self):
        setSize(self)
        self.setWindowTitle('test')
        self.loginUI()
        
        self.setLayout(self.login_ui)
        self.show()
    
    def loginUI(self):

        self.login_ui = QFormLayout()
        title = QLabel()
        title.setText('login')
        title.setFont(QFont('Fira Code', 18))
        title.setAlignment(Qt.AlignCenter)
        name_label = QLabel()
        name_label.setText('user name')
        name_label.setFont(QFont('Fira Code', 12))
        self.name_edit_line = QLineEdit()
        self.name_edit_line.setFont(QFont('Fira Code', 12))
        pwd_label = QLabel()
        pwd_label.setFont(QFont('Fira Code', 12))
        pwd_label.setText('password ')
        self.pwd_edit_line = QLineEdit()
        self.pwd_edit_line.setFont(QFont('Fira Code', 12))
        login_button = QPushButton()
        login_button.setFont(QFont('Fira Code', 12))
        login_button.setText('login')
        login_button.clicked.connect(self.loginHandler)
        sign_up_button = QPushButton()
        sign_up_button.setFont(QFont('Fira Code', 12))
        sign_up_button.setText('sign up')
        sign_up_button.clicked.connect(self.openSignUpWindow)
        admin_sign_in_button = QPushButton()
        admin_sign_in_button.setFont(QFont('Fira Code', 12))
        admin_sign_in_button.setText('admin sign in')
        admin_sign_in_button.clicked.connect(self.openAdminLoginWindow)
        self.login_ui.addWidget(title)
        self.login_ui.addWidget(makeHboxWidget(name_label, self.name_edit_line))
        self.login_ui.addWidget(makeHboxWidget(pwd_label, self.pwd_edit_line))
        self.login_ui.addWidget(login_button)
        self.login_ui.addWidget(sign_up_button)
        self.login_ui.addWidget(admin_sign_in_button)
    
    def loginHandler(self):
        for name in self.users:
            print(name[0])
        
        if (self.name_edit_line.text(),self.pwd_edit_line.text()) in self.users:
            print('nihao')
            self.openMainWindow(self.name_edit_line.text(), self.pwd_edit_line.text())

    @pyqtSlot(QTreeWidgetItem, int)
    def print_hello(self, it, col):
        print(it, col)
        print(self.hello)
        self.hello += 1

    def openSignUpWindow(self):
        self.new_window = SignUpWindow()
        self.new_window.show()
        

    def openAdminLoginWindow(self):
        self.new_window = AdminLoginWindow()
        self.new_window.show()
        self.hide()

    def openMainWindow(self, name, pwd):
        self.new_window = MainWindow(name, pwd)
        self.new_window.show()
        self.hide()
    
    def closeEvent(self, event):
        self.db.close()
        answer = QMessageBox.question(self, "Quit",
            "Are you sure you want to quit?", QMessageBox.No | QMessageBox.Yes, 
            QMessageBox.Yes)
        if answer == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()
        
class Database():
    def __init__(self, host, user, password, database):
        self.connection = mysql.connector.connect(
            host = host,
            user = user, 
            password = password,
            database = database
        )
        self.cursor = self.connection.cursor()
        
    def execute_query(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()
    def close(self):
        self.connection.commit()
        self.connection.close()

class SignUpWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initialize()
        self.show()
    def initialize(self):
        setSize(self)
        self.setWindowTitle('sign up page')
        self.signUpPage()
        self.setLayout(self.sign_up_page)
    def signUpPage(self):
        self.sign_up_page = QFormLayout()
        title = QLabel()
        title.setFont(QFont('Fira Code', 18))
        title.setText('Sign up')
        title.setAlignment(Qt.AlignCenter)
        name_label = QLabel()
        name_label.setFont(QFont('Fira Code', 12))
        name_label.setText('user name')
        self.name_edit_line = QLineEdit()
        self.name_edit_line.setFont(QFont('Fira Code', 12))
        pwd_label = QLabel()
        pwd_label.setFont(QFont('Fira Code', 12))
        pwd_label.setText('password')
        self.pwd_edit_line = QLineEdit()
        self.pwd_edit_line.setFont(QFont('Fira Code', 12))
        pwd_confirm_label = QLabel()
        pwd_confirm_label.setFont(QFont('Fira Code', 12))
        pwd_confirm_label.setText('confirm your password')
        pwd_confirm_edit_line = QLineEdit()
        pwd_confirm_edit_line.setFont(QFont('Fira Code', 12))
        label_box = QVBoxLayout()
        label_box.addWidget(name_label)
        label_box.addWidget(pwd_label)
        label_box.addWidget(pwd_confirm_label)
        line_edit_box = QVBoxLayout()
        line_edit_box.addWidget(self.name_edit_line)
        line_edit_box.addWidget(self.pwd_edit_line)
        line_edit_box.addWidget(pwd_confirm_edit_line)
        sign_up_button = QPushButton()
        sign_up_button.setFont(QFont('Fira Code', 12))
        sign_up_button.setText('sign up')
        sign_up_button.clicked.connect(self.sign_up_handler)
        self.sign_up_page.addWidget(title)
        self.sign_up_page.addWidget(makeHboxLayout(label_box, line_edit_box))
        self.sign_up_page.addWidget(sign_up_button)
    def sign_up_handler(self):
        print('sign up!')
        self.db = Database('localhost', 'root', 'zhrmghgws1', 'yum')
        self.db.execute_query("insert users (user_name, user_pwd)"
                              "values('{}', '{}');".format(self.name_edit_line.text(), self.pwd_edit_line.text()))
        self.db.execute_query("create user '{}'@'localhost' identified by '{}';".format(self.name_edit_line.text(), self.pwd_edit_line.text()))
        self.db.execute_query("GRANT ALL PRIVILEGES ON *.* TO '{}'@'localhost';".format(self.name_edit_line.text()))
        self.db.close();
        self.close();

class AdminLoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initialize()
    def initialize(self):
        setSize(self)
        self.setWindowTitle('admin login')
        self.adminPage()
        self.setLayout(self.admin_page)
    def adminPage(self):
        self.admin_page = QFormLayout()
        title = QLabel()
        title.setFont(QFont('Fira Code', 18))
        title.setText('Admin Login')
        title.setAlignment(Qt.AlignCenter)
        name_label = QLabel()
        name_label.setFont(QFont('Fira Code', 12))
        name_label.setText('admin name')
        self.name_edit_line = QLineEdit()
        self.name_edit_line.setFont(QFont('Fira Code', 12))
        pwd_label = QLabel()
        pwd_label.setFont(QFont('Fira Code', 12))
        pwd_label.setText('password')
        self.pwd_edit_line = QLineEdit()
        self.pwd_edit_line.setFont(QFont('Fira Code', 12))
        temp = QVBoxLayout()
        temp.addWidget(name_label)
        temp.addWidget(pwd_label)
        temp2 = QVBoxLayout()
        temp2.addWidget(self.name_edit_line)
        temp2.addWidget(self.pwd_edit_line)
        sign_in_button = QPushButton()
        sign_in_button.setFont(QFont('Fira Code', 12))
        sign_in_button.setText('sign in')
        sign_in_button.clicked.connect(self.openAdminWindow)
        self.admin_page.addWidget(title)
        self.admin_page.addWidget(makeHboxLayout(temp, temp2))
        self.admin_page.addWidget(sign_in_button)
    def openAdminWindow(self):
        self.new_window = AdminWindow(self.name_edit_line.text(), self.pwd_edit_line.text())
        self.new_window.show()
        self.hide()

class MainWindow(QWidget):
    def __init__(self, user_name, user_pwd):
        super().__init__()
        self.db = Database('localhost', user_name, user_pwd, 'yum')
        self.user_id = self.db.execute_query(
            "select user_id from users where user_name = '{}'".format(user_name))[0][0]
        self.hello = 1
        self.initializeUI()
    def initializeUI(self):
        self.setGeometry(400, 50, 1000, 1000)
        self.setWindowTitle('test')

        self.mainPage()
        self.setLayout(self.main_page)
        self.show()

    def mainPage(self):
        self.sidebarWidget()
        self.stackWidget()
        self.main_page = QHBoxLayout()
        self.main_page.addWidget(self.sidebar)
        self.main_page.addWidget(self.stack_layout)

    def sidebarWidget(self):
        self.sidebar = QTreeWidget()
        welcome = QTreeWidgetItem()
        welcome.setText(0, 'welcome page')
        welcome.setFont(0, QFont('Fira Code', 11))
        # welcome.setIcon(0, QIcon('images/canteen.jpg'))
        welcome.setText(1, 'welcome')
        welcome.setFont(1, QFont('Fira Code', 11))
        welcome.setText(2, 'can1')
        welcome.setFont(2, QFont('Fira Code', 11))
        welcome.setText(3, '1')


        top_1 = QTreeWidgetItem(["this is top 1"])
        top_1.setText(0, 'canteen 1')
        top_1.setFont(0, QFont('Fira Code', 11))
        top_1.setIcon(0, QIcon('images/canteen.jpg'))
        top_1.setText(1, 'canteen')
        top_1.setFont(1, QFont('Fira Code', 11))
        top_1.setText(2, 'can1')
        top_1.setFont(2, QFont('Fira Code', 11))
        top_1.setText(3, '1')

        top_2 = QTreeWidgetItem(["this is top 2"])
        top_2.setText(0, 'canteen 2')
        top_2.setFont(0, QFont('Fira Code', 11))
        top_2.setIcon(0, QIcon('images/canteen.jpg'))
        top_2.setText(1, 'canteen')
        top_2.setFont(1, QFont('Fira Code', 11))
        top_2.setText(2, 'can2')
        
        canteen_1 = QTreeWidgetItem(["this is top 2"])
        canteen_1.setText(0, 'canteen 1')
        canteen_1.setFont(0, QFont('Fira Code', 11))
        canteen_1.setIcon(0, QIcon('images/canteen.jpg'))
        canteen_1.setText(1, 'canteen')
        canteen_1.setFont(1, QFont('Fira Code', 11))
        canteen_1.setText(2, 'can1')
        canteen_1.setText(3, '1')

        canteen_2 = QTreeWidgetItem(["this is top 2"])
        canteen_2.setText(0, 'canteen 2')
        canteen_2.setFont(0, QFont('Fira Code', 11))
        canteen_2.setIcon(0, QIcon('images/canteen.jpg'))
        canteen_2.setText(1, 'canteen')
        canteen_2.setFont(1, QFont('Fira Code', 11))
        canteen_2.setText(2, 'can2')
        canteen_2.setText(3, '2')

        canteen_4 = QTreeWidgetItem(["this is top 2"])
        canteen_4.setText(0, 'canteen 4')
        canteen_4.setFont(0, QFont('Fira Code', 11))
        canteen_4.setIcon(0, QIcon('images/canteen.jpg'))
        canteen_4.setText(1, 'canteen')
        canteen_4.setFont(1, QFont('Fira Code', 11))
        canteen_4.setText(2, 'can4')
        canteen_4.setText(3, '3')
        
        child_1 = QTreeWidgetItem(["this is child 1"])
        child_1.setText(0, 'child 1')
        child_1.setFont(0, QFont('Fira Code', 11))
        child_1.setIcon(0, QIcon('images/store.png'))
        child_1.setText(1, 'store')
        child_1.setFont(1, QFont('Fira Code', 11))
        child_1.setText(2, '1')

        child_2 = QTreeWidgetItem(["this is child 1"])
        child_2.setText(0, 'child 2')
        child_2.setFont(0, QFont('Fira Code', 11))
        child_2.setIcon(0, QIcon('images/store.png'))
        child_2.setText(1, 'store')
        child_2.setFont(1, QFont('Fira Code', 11))
        child_2.setText(2, '2')

        store_1 = QTreeWidgetItem(["this is child 1"])
        store_1.setText(0, '包子铺')
        store_1.setFont(0, QFont('Fira Code', 11))
        store_1.setIcon(0, QIcon('images/store.png'))
        store_1.setText(1, 'store')
        store_1.setFont(1, QFont('Fira Code', 11))
        store_1.setText(2, '1')

        store_2 = QTreeWidgetItem(["this is child 1"])
        store_2.setText(0, '烤冷面')
        store_2.setFont(0, QFont('Fira Code', 11))
        store_2.setIcon(0, QIcon('images/store.png'))
        store_2.setText(1, 'store')
        store_2.setFont(1, QFont('Fira Code', 11))
        store_2.setText(2, '2')

        store_3 = QTreeWidgetItem(["this is child 1"])
        store_3.setText(0, '猪肚鸡')
        store_3.setFont(0, QFont('Fira Code', 11))
        store_3.setIcon(0, QIcon('images/store.png'))
        store_3.setText(1, 'store')
        store_3.setFont(1, QFont('Fira Code', 11))
        store_3.setText(2, '3')

        store_4 = QTreeWidgetItem(["this is child 1"])
        store_4.setText(0, '小炒菜')
        store_4.setFont(0, QFont('Fira Code', 11))
        store_4.setIcon(0, QIcon('images/store.png'))
        store_4.setText(1, 'store')
        store_4.setFont(1, QFont('Fira Code', 11))
        store_4.setText(2, '4')

        store_5 = QTreeWidgetItem(["this is child 1"])
        store_5.setText(0, '东北菜')
        store_5.setFont(0, QFont('Fira Code', 11))
        store_5.setIcon(0, QIcon('images/store.png'))
        store_5.setText(1, 'store')
        store_5.setFont(1, QFont('Fira Code', 11))
        store_5.setText(2, '5')
        
        store_6 = QTreeWidgetItem(["this is child 1"])
        store_6.setText(0, '木桶饭')
        store_6.setFont(0, QFont('Fira Code', 11))
        store_6.setIcon(0, QIcon('images/store.png'))
        store_6.setText(1, 'store')
        store_6.setFont(1, QFont('Fira Code', 11))
        store_6.setText(2, '6')

        top_1.addChild(child_1)
        top_2.addChild(child_2)
        
        canteen_1.addChild(store_1)
        canteen_1.addChild(store_2)
        canteen_1.addChild(store_3)
        canteen_2.addChild(store_4)
        canteen_4.addChild(store_5)
        canteen_4.addChild(store_6)
        
        order = QTreeWidgetItem(["this is child 1"])
        order.setText(0, 'order page')
        order.setFont(0, QFont('Fira Code', 11))
        order.setIcon(0, QIcon('images/order.png'))
        order.setText(1, 'order')
        order.setFont(1, QFont('Fira Code', 11))
        order.setText(2, '2')

        self.sidebar.setColumnCount(1)
        self.sidebar.expandAll()
        self.sidebar.addTopLevelItem(welcome)
        self.sidebar.addTopLevelItem(canteen_1)
        self.sidebar.addTopLevelItem(canteen_2)
        self.sidebar.addTopLevelItem(canteen_4)
        self.sidebar.addTopLevelItem(order)
        self.sidebar.itemClicked.connect(self.tree_handler)

    @pyqtSlot(QTreeWidgetItem, int)
    def tree_handler(self, it, col):
        def setImage(image_path):
            self.image_label.setPixmap(QPixmap('images/' + image_path).scaledToHeight(200))

        if it.text(1) == 'canteen':
            self.selected = -1
            setImage(it.text(2) + '.jpg')
            self.change_canteen_view()
            self.stack_layout.setCurrentIndex(1)
        elif it.text(1) == 'store':
            # note it text 2 stores store id
            self.selected = -1
            self.store_id = it.text(2)
            self.change_store_item_table()
            self.stack_layout.setCurrentIndex(2)
        elif it.text(1) == 'order':
            self.change_order_view()
            self.stack_layout.setCurrentIndex(3)
        elif it.text(1) == 'welcome':
            self.change_welcome_view()
            self.stack_layout.setCurrentIndex(0)
            

    def stackWidget(self):
        def create_widget(layout):
            widget = QWidget(self.stack_layout)
            widget.setLayout(layout)
            return widget

        self.stackWelcomeLayout()
        self.stackCanteenLayout()
        self.stackStoreLayout()
        self.stackOrderLayout()

        self.stack_layout = QStackedWidget()
        self.stack_layout.addWidget(create_widget(self.welcome_layout))
        self.stack_layout.addWidget(create_widget(self.canteen_layout))
        self.stack_layout.addWidget(create_widget(self.store_layout))
        self.stack_layout.addWidget(create_widget(self.order_page))
    

    def stackCanteenLayout(self):
        self.descriptionLayout('images/image.jpg')
        self.tableWidget()
        self.canteen_layout = QVBoxLayout()

        button = QPushButton('back to welcome page')
        button.setFont(QFont('Fira Code', 12))
        button.clicked.connect(lambda: self.stack_layout.setCurrentIndex(0))

        test_button1 = QPushButton('test button')
        test_button1.setFont(QFont('Fira Code', 12))
        test_button1.clicked.connect(lambda: self.stack_layout.setCurrentIndex(2))
        
        self.canteen_layout.addWidget(test_button1)
        self.canteen_layout.addWidget(button)
        self.canteen_layout.addLayout(self.description_layout)
        self.canteen_layout.addWidget(self.table_widget.getTable())

    def stackStoreLayout(self):
        self.selected_item_row = -1;
        self.store_layout = QVBoxLayout()
        test_button2 = QPushButton('test button')
        test_button2.setFont(QFont('Fira Code', 12))
        test_button2.clicked.connect(lambda: self.stack_layout.setCurrentIndex(1))
        test_label = QLabel()
        test_label.setText('这里是store界面')
        test_label.setFont(QFont('Fira Code',12))
        order_button = QPushButton('make order')
        order_button.setFont(QFont('Fira Code', 12))
        order_button.clicked.connect(self.makeOrder)

        self.store_item_table = TableWidget()
        self.store_item_table.getTable().itemClicked.connect(self.selectStoreItem)
        
        self.store_layout.addWidget(test_button2)
        self.store_layout.addWidget(test_label)
        self.store_layout.addWidget(order_button)
        self.store_layout.addWidget(self.store_item_table.getTable())

    
        
    def stackOrderLayout(self):
        self.order_table = TableWidget()
        self.selected_order_number = -1;

        self.order_page = QVBoxLayout()
        label = QLabel()
        label.setText('Here is your orders!')
        label.setFont(QFont('Fira Code', 12))
        label.setAlignment(Qt.AlignCenter)

        pushButton = QPushButton()
        pushButton.setText('Leave a comment on your order')
        pushButton.setFont(QFont('Fira Code', 12))
        pushButton.clicked.connect(self.make_comment)
        
        rate_label = QLabel()
        rate_label.setText('rate?')
        rate_label.setFont(QFont('Fira Code', 12))

        self.rate_combox_box = QComboBox()
        self.rate_combox_box.addItem('5')
        self.rate_combox_box.addItem('4')
        self.rate_combox_box.addItem('3')
        self.rate_combox_box.addItem('2')
        self.rate_combox_box.addItem('1')
        self.rate_combox_box.setFont(QFont('Fira Code', 12))
        
        hbox1 = QHBoxLayout()
        hbox1.addWidget(rate_label)
        hbox1.addWidget(self.rate_combox_box)

        self.comment_content_block = QTextEdit(self)
        self.comment_content_block.setFont(QFont('Fira Code', 12))
        
        hbox = QHBoxLayout()
        hbox.addLayout(hbox1)
        hbox.addWidget(self.comment_content_block)

        vbox = QVBoxLayout()
        vbox.addLayout(hbox)
        vbox.addWidget(pushButton)

        self.order_page.addWidget(label)
        self.order_page.addWidget(self.order_table.getTable())
        self.order_page.addLayout(vbox)

    
    def stackWelcomeLayout(self):
        self.welcome_layout = QVBoxLayout()
        label = QLabel()
        label.setText('Welcome!')
        label.setFont(QFont('Fira Code', 16))
        label.setAlignment(Qt.AlignCenter)
        label1 = QLabel()
        label1.setText('click sidebar item to navigate')
        label1.setFont(QFont('Fira Code', 14))
        label1.setAlignment(Qt.AlignCenter)
        
        self.review_table = TableWidget()
        self.change_welcome_view()

        self.welcome_layout.addWidget(label)
        self.welcome_layout.addWidget(label1)
        self.welcome_layout.addWidget(self.review_table.getTable())
    
    def descriptionLayout(self, image_path):
        self.description_layout = QHBoxLayout()
        self.image_label = QLabel(self)
        self.image_label.setPixmap(QPixmap(image_path).scaledToHeight(200))
        text_label = QLabel()
        text_label.setText('这里是餐厅界面')
        text_label.setFont(QFont('Fira Code', 14))
        self.description_layout.addWidget(self.image_label)
        self.description_layout.addWidget(text_label)

    def tableWidget(self):
        self.table_widget = TableWidget()
        self.table_widget.getTable().itemClicked.connect(self.table_hello)
        
        # TODO
        foo = test_query(self)
        self.table_widget.stuffTable(foo)

    def selectStoreItem(self):
        self.selected_item_row = self.store_item_table.getTable().currentRow()
        self.selected_item_id = self.store_item_table.getTable().item(self.selected_item_row, 0).text()
        print(self.selected_item_id)

    def makeOrder(self):
        answer = QMessageBox.question(self, "make order",
            "Are you sure you want to make order?", QMessageBox.No | QMessageBox.Yes, 
            QMessageBox.Yes)
        if answer == QMessageBox.Yes:
            make_order_query(self, self.user_id, None, self.selected_item_id, self.store_id)

    def table_hello(self):
        # for canteen table
        col = 0;
        print(self.table_widget.getTable().item(self.table_widget.getTable().currentRow(), col).text())

    def change_store_item_table(self):
        print('change store item table')
        foo = self.db.execute_query('select * from item where store_id = {}'.format(self.store_id))
        self.store_item_table.stuffTable(foo)

    def change_canteen_view(self):
        print('change canteen view')
        foo = get_canteen_review(self, self.sidebar.currentItem().text(3))
        self.table_widget.stuffTable(foo)
        
    def change_order_view(self):
        print('change order view')
        foo = self.db.execute_query(
            'select * from an_order where user_id = {};'.format(str(self.user_id)))
        self.order_table.stuffTable(foo)

    def make_comment(self):
        print('make comment')
        answer = QMessageBox.question(self, "Comment?",
            "Are you sure you want to comment?", QMessageBox.No | QMessageBox.Yes, 
            QMessageBox.Yes)
        if (answer == QMessageBox.Yes):
            content = self.comment_content_block.toPlainText()
            self.selected_order_id = \
                self.order_table.getTable().item(self.order_table.getTable().currentRow(), 0).text()
            make_comment_query(self, 
                               self.selected_order_id, 
                               self.rate_combox_box.currentText(), 
                               content)
            print('comment recieved')

    def change_welcome_view(self):
        print('change welcome view')
        foo = self.db.execute_query('select * from review;')
        self.review_table.stuffTable(foo)

    def closeEvent(self, event):
        self.db.close()
        answer = QMessageBox.question(self, "Quit",
            "Are you sure you want to quit?", QMessageBox.No | QMessageBox.Yes, 
            QMessageBox.Yes)
        if answer == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()
        
class AdminWindow(QWidget):
    # adminwindow is used to process some orders
    def __init__(self, name, pwd):
        super().__init__()
        self.setGeometry(400, 50, 1000, 1000)
        self.db = Database('localhost', name, pwd, 'yum')

        self.selected = -1
        self.initializeUI()
    def initializeUI(self):
        self.adminWindow()
        self.setLayout(self.admin_window)
        self.show()
        
    def adminWindow(self):
        self.tableWidget()
        self.pushButton()

        self.admin_window = QVBoxLayout()
        self.admin_window.addWidget(self.table_widget.getTable())
        self.admin_window.addWidget(self.button)

    def pushButton(self):
        self.button = QPushButton()
        self.button.clicked.connect(self.pushAction)
        self.button.setFont(QFont('Fira Code', 14))
        self.button.setText('Process Order')

    def tableWidget(self):
        self.table_widget = TableWidget()
        self.table_widget.getTable().itemClicked.connect(self.table_handle)
        
        self.change_view()

    def table_handle(self):
        self.selected = self.table_widget.getTable().currentRow()
        print(self.selected)

    def pushAction(self):
        print('process order')
        print(self.table_widget.getTable().item(self.selected, 0).text())
        process_order_query(self, self.table_widget.getTable().item(self.selected, 0).text())
        self.change_view()
        print(self.selected)

    def change_view(self):
        foo = self.db.execute_query('select * from an_order;')
        self.table_widget.stuffTable(foo)

class TableWidget(QTableWidget):
    def __init__(self):
        super().__init__()
        self.table_widget = QTableWidget(self)
        self.table_widget.setFont(QFont('Fira Code', 9))
        
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(4)

    def getTable(self):
        return self.table_widget

    def stuffTable(self, foo):
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(3)

        for row_number, row_data in enumerate(foo):
            self.table_widget.insertRow(row_number)
            for (column_number, data) in enumerate(row_data):
                item = QTableWidgetItem(str(data))
                self.table_widget.setItem(row_number, column_number, item)
        
def test_query(self):
    return self.db.execute_query('select * from item;')

def make_order_query(self, user_id, order_time, item_id, store_id):
    print(item_id)
    self.db.execute_query('insert an_order (user_id, item_id, store_id) '
                          'values ({}, {}, {});'.format(str(user_id), str(item_id), store_id))

def make_comment_query(self, order_id, rate, content):
    print(content)
    print(rate)
    self.db.execute_query("insert review (order_id, rate, content)"
                          "values ({}, {}, '{}');".format(order_id, rate, content))
    
def setSize(self):
    self.setGeometry(100,100,600,400)

def process_order_query(self, order_id):
    print(order_id)
    self.db.execute_query('update order_states '
                          'set order_state = 1 '
                          'where order_id = {};'.format(order_id))

def get_canteen_review(self, canteen_id):
    print(canteen_id)
    data = []
    self.db.cursor.callproc('getCanteenReview', [int(canteen_id)])
    for result in self.db.cursor.stored_results():
        rows = result.fetchall()
        for row in rows:
            data.append(tuple(row))
    return data

def makeHboxWidget(widget_1, widget_2):
    temp = QHBoxLayout()
    temp.addWidget(widget_1)
    temp.addWidget(widget_2)
    temp2 = QWidget()
    temp2.setLayout(temp)
    return temp2

def makeHboxLayout(layout_1, layout_2):
    temp = QHBoxLayout()
    temp.addLayout(layout_1)
    temp.addLayout(layout_2)
    temp2 = QWidget()
    temp2.setLayout(temp)
    return temp2

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = LoginWindow()
    sys.exit(app.exec_())
